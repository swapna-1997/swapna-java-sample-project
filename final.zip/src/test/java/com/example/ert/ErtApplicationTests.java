package com.example.ert;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ErtApplicationTests {
    @Test
    void contextLoads() {
    }
}
