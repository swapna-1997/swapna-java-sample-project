INSERT INTO robot (id, code, model, firmware_version, active, created_at, updated_at) VALUES
  (1, 'RB-001', 'AlphaBot', 'v1.0.0', true, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());

INSERT INTO course (id, code, title, description, capacity, created_at, updated_at) VALUES
  (1, 'C-INTRO', 'Intro to Robotics', 'Basics of robot operation', 30, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());
