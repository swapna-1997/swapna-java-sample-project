package com.example.ert;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ErtApplication {
    public static void main(String[] args) {
        SpringApplication.run(ErtApplication.class, args);
    }
}
