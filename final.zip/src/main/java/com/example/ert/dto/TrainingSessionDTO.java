package com.example.ert.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class TrainingSessionDTO {
    private Long id;
    @NotNull
    private Long courseId;
    @NotNull
    private Long robotId;
    @NotNull
    private LocalDateTime startTime;
    @NotNull
    private LocalDateTime endTime;
    private String location;
}
