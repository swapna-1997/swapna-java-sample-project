package com.example.ert.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class RobotDTO {
    private Long id;
    @NotBlank
    private String code;
    @NotBlank
    private String model;
    private String firmwareVersion;
    private boolean active = true;
}
