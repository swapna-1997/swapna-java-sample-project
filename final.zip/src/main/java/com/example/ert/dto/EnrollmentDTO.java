package com.example.ert.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class EnrollmentDTO {
    private Long id;
    @NotNull
    private Long studentId;
    @NotNull
    private Long courseId;
}
