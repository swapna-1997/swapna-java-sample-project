package com.example.ert.validator;

import com.example.ert.dto.RobotDTO;
import org.springframework.stereotype.Component;

@Component
public class RobotValidator {

    public void validate(RobotDTO dto) {
        // Example: firmwareVersion format "vX.Y.Z"
        if (dto.getFirmwareVersion() != null && !dto.getFirmwareVersion().isBlank()) {
            if (!dto.getFirmwareVersion().matches("v?\\d+\\.\\d+\\.\\d+")) {
                throw new IllegalArgumentException("Invalid firmwareVersion format. Expected vX.Y.Z");
            }
        }
    }
}
