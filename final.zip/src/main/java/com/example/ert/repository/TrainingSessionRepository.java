package com.example.ert.repository;

import com.example.ert.entity.TrainingSession;
import com.example.ert.entity.Robot;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDateTime;
import java.util.List;

public interface TrainingSessionRepository extends JpaRepository<TrainingSession, Long> {
    @Query("select ts from TrainingSession ts where ts.robot = :robot and ts.endTime > :start and ts.startTime < :end")
    List<TrainingSession> findOverlappingSessions(Robot robot, LocalDateTime start, LocalDateTime end);

    List<TrainingSession> findByCourse_Id(Long courseId);
    List<TrainingSession> findByRobot_Id(Long robotId);
}
