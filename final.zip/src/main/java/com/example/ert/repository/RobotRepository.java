package com.example.ert.repository;

import com.example.ert.entity.Robot;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface RobotRepository extends JpaRepository<Robot, Long> {
    boolean existsByCode(String code);
    Optional<Robot> findByCode(String code);
}
