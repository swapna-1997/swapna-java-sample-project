package com.example.ert.controller;

import com.example.ert.dto.TrainingSessionDTO;
import com.example.ert.service.TrainingSessionService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/sessions")
public class TrainingSessionController {

    private final TrainingSessionService service;

    public TrainingSessionController(TrainingSessionService service) {
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public TrainingSessionDTO schedule(@Valid @RequestBody TrainingSessionDTO dto) {
        return service.schedule(dto);
    }

    @PutMapping("/{id}")
    public TrainingSessionDTO reschedule(@PathVariable Long id, @Valid @RequestBody TrainingSessionDTO dto) {
        return service.reschedule(id, dto);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void cancel(@PathVariable Long id) {
        service.cancel(id);
    }

    @GetMapping("/{id}")
    public TrainingSessionDTO get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<TrainingSessionDTO> list() {
        return service.list();
    }

    @GetMapping("/by-course/{courseId}")
    public List<TrainingSessionDTO> byCourse(@PathVariable Long courseId) {
        return service.listByCourse(courseId);
    }

    @GetMapping("/by-robot/{robotId}")
    public List<TrainingSessionDTO> byRobot(@PathVariable Long robotId) {
        return service.listByRobot(robotId);
    }
}
