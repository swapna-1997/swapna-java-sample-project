package com.example.ert.controller;

import com.example.ert.dto.RobotDTO;
import com.example.ert.service.RobotService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/robots")
public class RobotController {

    private final RobotService service;

    public RobotController(RobotService service) {
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public RobotDTO create(@Valid @RequestBody RobotDTO dto) {
        return service.create(dto);
    }

    @PutMapping("/{id}")
    public RobotDTO update(@PathVariable Long id, @Valid @RequestBody RobotDTO dto) {
        return service.update(id, dto);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }

    @GetMapping("/{id}")
    public RobotDTO get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<RobotDTO> list() {
        return service.list();
    }
}
