package com.example.ert.controller;

import com.example.ert.dto.EnrollmentDTO;
import com.example.ert.service.EnrollmentService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/enrollments")
public class EnrollmentController {

    private final EnrollmentService service;

    public EnrollmentController(EnrollmentService service) {
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public EnrollmentDTO enroll(@RequestParam Long studentId, @RequestParam Long courseId) {
        return service.enrollStudent(studentId, courseId);
    }

    @DeleteMapping
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void drop(@RequestParam Long studentId, @RequestParam Long courseId) {
        service.dropEnrollment(studentId, courseId);
    }

    @GetMapping("/by-student/{studentId}")
    public List<EnrollmentDTO> getByStudent(@PathVariable Long studentId) {
        return service.getEnrollmentsByStudent(studentId);
    }

    @GetMapping("/by-course/{courseId}")
    public List<EnrollmentDTO> getByCourse(@PathVariable Long courseId) {
        return service.getEnrollmentsByCourse(courseId);
    }
}
