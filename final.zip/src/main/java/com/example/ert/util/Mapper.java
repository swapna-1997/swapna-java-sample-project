package com.example.ert.util;

import com.example.ert.dto.*;
import com.example.ert.entity.*;

public final class Mapper {
    private Mapper() {}

    // ---------------- ROBOT ----------------
    public static RobotDTO toDTO(Robot e) {
        if (e == null) return null;
        RobotDTO d = new RobotDTO();
        d.setId(e.getId());
        d.setCode(e.getCode());
        d.setModel(e.getModel());
        d.setFirmwareVersion(e.getFirmwareVersion());
        d.setActive(e.isActive());
        return d;
    }

    public static Robot toEntity(RobotDTO d) {
        if (d == null) return null;
        Robot robot = Robot.builder()
                .code(d.getCode())
                .model(d.getModel())
                .firmwareVersion(d.getFirmwareVersion())
                .active(d.isActive())
                .build();
        robot.setId(d.getId());
        return robot;
    }

    // ---------------- STUDENT ----------------
    public static StudentDTO toDTO(Student e) {
        if (e == null) return null;
        StudentDTO d = new StudentDTO();
        d.setId(e.getId());
        d.setName(e.getName());
        d.setEmail(e.getEmail());
        d.setGradeLevel(e.getGradeLevel());
        return d;
    }

    public static Student toEntity(StudentDTO d) {
        if (d == null) return null;
        Student student = Student.builder()
                .name(d.getName())
                .email(d.getEmail())
                .gradeLevel(d.getGradeLevel())
                .build();
        student.setId(d.getId());
        return student;
    }

    // ---------------- COURSE ----------------
    public static CourseDTO toDTO(Course e) {
        if (e == null) return null;
        CourseDTO d = new CourseDTO();
        d.setId(e.getId());
        d.setCode(e.getCode());
        d.setTitle(e.getTitle());
        d.setDescription(e.getDescription());
        d.setCapacity(e.getCapacity());
        return d;
    }

    public static Course toEntity(CourseDTO d) {
        if (d == null) return null;
        Course course = Course.builder()
                .code(d.getCode())
                .title(d.getTitle())
                .description(d.getDescription())
                .capacity(d.getCapacity())
                .build();
        course.setId(d.getId());
        return course;
    }

    // ---------------- TRAINING SESSION ----------------
    public static TrainingSessionDTO toDTO(TrainingSession e) {
        if (e == null) return null;
        TrainingSessionDTO d = new TrainingSessionDTO();
        d.setId(e.getId());
        d.setCourseId(e.getCourse().getId());
        d.setRobotId(e.getRobot().getId());
        d.setStartTime(e.getStartTime());
        d.setEndTime(e.getEndTime());
        d.setLocation(e.getLocation());
        return d;
    }

    // ---------------- ENROLLMENT ----------------
    public static EnrollmentDTO toDTO(Enrollment e) {
        if (e == null) return null;
        EnrollmentDTO d = new EnrollmentDTO();
        d.setId(e.getId());
        d.setStudentId(e.getStudent().getId());
        d.setCourseId(e.getCourse().getId());
        return d;
    }
}
