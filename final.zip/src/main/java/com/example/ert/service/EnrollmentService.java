package com.example.ert.service;

import com.example.ert.dto.EnrollmentDTO;
import java.util.List;

public interface EnrollmentService {

    EnrollmentDTO enrollStudent(Long studentId, Long courseId);

    void dropEnrollment(Long studentId, Long courseId);

    List<EnrollmentDTO> getEnrollmentsByStudent(Long studentId);

    List<EnrollmentDTO> getEnrollmentsByCourse(Long courseId);
}
