package com.example.ert.service;

import com.example.ert.dto.RobotDTO;
import java.util.List;

public interface RobotService {
    RobotDTO create(RobotDTO dto);
    RobotDTO update(Long id, RobotDTO dto);
    void delete(Long id);
    RobotDTO get(Long id);
    List<RobotDTO> list();
}
