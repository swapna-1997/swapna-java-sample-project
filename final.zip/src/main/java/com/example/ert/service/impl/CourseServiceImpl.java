package com.example.ert.service.impl;

import com.example.ert.dto.CourseDTO;
import com.example.ert.entity.Course;
import com.example.ert.repository.CourseRepository;
import com.example.ert.service.CourseService;
import com.example.ert.util.Mapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class CourseServiceImpl implements CourseService {

    private final CourseRepository repo;

    public CourseServiceImpl(CourseRepository repo) {
        this.repo = repo;
    }

    @Override
    public CourseDTO create(CourseDTO dto) {
        if (repo.existsByCode(dto.getCode())) {
            throw new IllegalArgumentException("Course code already exists");
        }
        Course saved = repo.save(Mapper.toEntity(dto));
        return Mapper.toDTO(saved);
    }

    @Override
    public CourseDTO update(Long id, CourseDTO dto) {
        Course existing = repo.findById(id).orElseThrow(() -> new IllegalArgumentException("Course not found"));
        if (!existing.getCode().equals(dto.getCode()) && repo.existsByCode(dto.getCode())) {
            throw new IllegalArgumentException("Course code already exists");
        }
        existing.setCode(dto.getCode());
        existing.setTitle(dto.getTitle());
        existing.setDescription(dto.getDescription());
        existing.setCapacity(dto.getCapacity());
        return Mapper.toDTO(existing);
    }

    @Override
    public void delete(Long id) {
        repo.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public CourseDTO get(Long id) {
        return repo.findById(id).map(Mapper::toDTO)
                .orElseThrow(() -> new IllegalArgumentException("Course not found"));
    }

    @Override
    @Transactional(readOnly = true)
    public List<CourseDTO> list() {
        return repo.findAll().stream().map(Mapper::toDTO).toList();
    }
}
