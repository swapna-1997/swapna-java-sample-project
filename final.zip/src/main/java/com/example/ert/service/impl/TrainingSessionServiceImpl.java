package com.example.ert.service.impl;

import com.example.ert.dto.TrainingSessionDTO;
import com.example.ert.entity.Course;
import com.example.ert.entity.Robot;
import com.example.ert.entity.TrainingSession;
import com.example.ert.repository.CourseRepository;
import com.example.ert.repository.RobotRepository;
import com.example.ert.repository.TrainingSessionRepository;
import com.example.ert.service.TrainingSessionService;
import com.example.ert.util.Mapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class TrainingSessionServiceImpl implements TrainingSessionService {

    private final TrainingSessionRepository repo;
    private final CourseRepository courseRepo;
    private final RobotRepository robotRepo;

    public TrainingSessionServiceImpl(TrainingSessionRepository repo, CourseRepository courseRepo, RobotRepository robotRepo) {
        this.repo = repo;
        this.courseRepo = courseRepo;
        this.robotRepo = robotRepo;
    }

    @Override
    public TrainingSessionDTO schedule(TrainingSessionDTO dto) {
        if (!dto.getEndTime().isAfter(dto.getStartTime())) {
            throw new IllegalArgumentException("endTime must be after startTime");
        }
        Course course = courseRepo.findById(dto.getCourseId()).orElseThrow(() -> new IllegalArgumentException("Course not found"));
        Robot robot = robotRepo.findById(dto.getRobotId()).orElseThrow(() -> new IllegalArgumentException("Robot not found"));
        // Overlap check for robot
        List<TrainingSession> overlaps = repo.findOverlappingSessions(robot, dto.getStartTime(), dto.getEndTime());
        if (!overlaps.isEmpty()) {
            throw new IllegalArgumentException("Robot has an overlapping session");
        }
        TrainingSession ts = TrainingSession.builder()
                .course(course)
                .robot(robot)
                .startTime(dto.getStartTime())
                .endTime(dto.getEndTime())
                .location(dto.getLocation())
                .build();
        return Mapper.toDTO(repo.save(ts));
    }

    @Override
    public TrainingSessionDTO reschedule(Long id, TrainingSessionDTO dto) {
        TrainingSession existing = repo.findById(id).orElseThrow(() -> new IllegalArgumentException("TrainingSession not found"));
        if (!dto.getEndTime().isAfter(dto.getStartTime())) {
            throw new IllegalArgumentException("endTime must be after startTime");
        }
        Robot robot = robotRepo.findById(dto.getRobotId()).orElseThrow(() -> new IllegalArgumentException("Robot not found"));
        // Overlap check (exclude current session)
        List<TrainingSession> overlaps = repo.findOverlappingSessions(robot, dto.getStartTime(), dto.getEndTime())
                .stream().filter(ts -> !ts.getId().equals(existing.getId())).toList();
        if (!overlaps.isEmpty()) {
            throw new IllegalArgumentException("Robot has an overlapping session");
        }
        existing.setCourse(courseRepo.findById(dto.getCourseId()).orElseThrow(() -> new IllegalArgumentException("Course not found")));
        existing.setRobot(robot);
        existing.setStartTime(dto.getStartTime());
        existing.setEndTime(dto.getEndTime());
        existing.setLocation(dto.getLocation());
        return Mapper.toDTO(existing);
    }

    @Override
    public void cancel(Long id) {
        repo.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public TrainingSessionDTO get(Long id) {
        return repo.findById(id).map(Mapper::toDTO)
                .orElseThrow(() -> new IllegalArgumentException("TrainingSession not found"));
    }

    @Override
    @Transactional(readOnly = true)
    public List<TrainingSessionDTO> list() {
        return repo.findAll().stream().map(Mapper::toDTO).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<TrainingSessionDTO> listByCourse(Long courseId) {
        return repo.findByCourse_Id(courseId).stream().map(Mapper::toDTO).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<TrainingSessionDTO> listByRobot(Long robotId) {
        return repo.findByRobot_Id(robotId).stream().map(Mapper::toDTO).toList();
    }
}
