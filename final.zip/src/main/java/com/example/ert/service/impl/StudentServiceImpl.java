package com.example.ert.service.impl;

import com.example.ert.dto.StudentDTO;
import com.example.ert.entity.Student;
import com.example.ert.repository.StudentRepository;
import com.example.ert.service.StudentService;
import com.example.ert.util.Mapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class StudentServiceImpl implements StudentService {

    private final StudentRepository repo;

    public StudentServiceImpl(StudentRepository repo) {
        this.repo = repo;
    }

    @Override
    public StudentDTO create(StudentDTO dto) {
        if (repo.existsByEmail(dto.getEmail())) {
            throw new IllegalArgumentException("Email already exists");
        }
        Student saved = repo.save(Mapper.toEntity(dto));
        return Mapper.toDTO(saved);
    }

    @Override
    public StudentDTO update(Long id, StudentDTO dto) {
        Student existing = repo.findById(id).orElseThrow(() -> new IllegalArgumentException("Student not found"));
        if (!existing.getEmail().equals(dto.getEmail()) && repo.existsByEmail(dto.getEmail())) {
            throw new IllegalArgumentException("Email already exists");
        }
        existing.setName(dto.getName());
        existing.setEmail(dto.getEmail());
        existing.setGradeLevel(dto.getGradeLevel());
        return Mapper.toDTO(existing);
    }

    @Override
    public void delete(Long id) {
        repo.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public StudentDTO get(Long id) {
        return repo.findById(id).map(Mapper::toDTO)
                .orElseThrow(() -> new IllegalArgumentException("Student not found"));
    }

    @Override
    @Transactional(readOnly = true)
    public List<StudentDTO> list() {
        return repo.findAll().stream().map(Mapper::toDTO).toList();
    }
}
