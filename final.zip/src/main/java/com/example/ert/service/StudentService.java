package com.example.ert.service;

import com.example.ert.dto.StudentDTO;
import java.util.List;

public interface StudentService {
    StudentDTO create(StudentDTO dto);
    StudentDTO update(Long id, StudentDTO dto);
    void delete(Long id);
    StudentDTO get(Long id);
    List<StudentDTO> list();
}
