package com.example.ert.service;

import com.example.ert.dto.CourseDTO;
import java.util.List;

public interface CourseService {
    CourseDTO create(CourseDTO dto);
    CourseDTO update(Long id, CourseDTO dto);
    void delete(Long id);
    CourseDTO get(Long id);
    List<CourseDTO> list();
}
