package com.example.ert.service.impl;

import com.example.ert.dto.EnrollmentDTO;
import com.example.ert.entity.Course;
import com.example.ert.entity.Enrollment;
import com.example.ert.entity.Student;
import com.example.ert.repository.CourseRepository;
import com.example.ert.repository.EnrollmentRepository;
import com.example.ert.repository.StudentRepository;
import com.example.ert.service.EnrollmentService;
import com.example.ert.util.Mapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class EnrollmentServiceImpl implements EnrollmentService {

    private final EnrollmentRepository enrollmentRepository;
    private final StudentRepository studentRepository;
    private final CourseRepository courseRepository;

    @Override
    public EnrollmentDTO enrollStudent(Long studentId, Long courseId) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found"));
        Course course = courseRepository.findById(courseId)
                .orElseThrow(() -> new RuntimeException("Course not found"));

        Enrollment enrollment = new Enrollment();
        enrollment.setStudent(student);
        enrollment.setCourse(course);
        return Mapper.toDTO(enrollmentRepository.save(enrollment));
    }

    @Override
    public void dropEnrollment(Long studentId, Long courseId) {
        Enrollment enrollment = enrollmentRepository
                .findByStudentIdAndCourseId(studentId, courseId)
                .orElseThrow(() -> new RuntimeException("Enrollment not found"));
        enrollmentRepository.delete(enrollment);
    }

    @Override
    public List<EnrollmentDTO> getEnrollmentsByStudent(Long studentId) {
        return enrollmentRepository.findByStudentId(studentId)
                .stream().map(Mapper::toDTO).toList();
    }

    @Override
    public List<EnrollmentDTO> getEnrollmentsByCourse(Long courseId) {
        return enrollmentRepository.findByCourseId(courseId)
                .stream().map(Mapper::toDTO).toList();
    }
}
