package com.example.ert.service.impl;

import com.example.ert.dto.RobotDTO;
import com.example.ert.entity.Robot;
import com.example.ert.repository.RobotRepository;
import com.example.ert.service.RobotService;
import com.example.ert.util.Mapper;
import com.example.ert.validator.RobotValidator;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class RobotServiceImpl implements RobotService {

    private final RobotRepository robotRepository;
    private final RobotValidator robotValidator;

    public RobotServiceImpl(RobotRepository robotRepository, RobotValidator robotValidator) {
        this.robotRepository = robotRepository;
        this.robotValidator = robotValidator;
    }

    @Override
    public RobotDTO create(RobotDTO dto) {
        robotValidator.validate(dto);
        if (robotRepository.existsByCode(dto.getCode())) {
            throw new IllegalArgumentException("Robot code already exists");
        }
        Robot saved = robotRepository.save(Mapper.toEntity(dto));
        return Mapper.toDTO(saved);
    }

    @Override
    public RobotDTO update(Long id, RobotDTO dto) {
        robotValidator.validate(dto);
        Robot existing = robotRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Robot not found"));
        if (!existing.getCode().equals(dto.getCode()) && robotRepository.existsByCode(dto.getCode())) {
            throw new IllegalArgumentException("Robot code already exists");
        }
        existing.setCode(dto.getCode());
        existing.setModel(dto.getModel());
        existing.setFirmwareVersion(dto.getFirmwareVersion());
        existing.setActive(dto.isActive());
        return Mapper.toDTO(existing);
    }

    @Override
    public void delete(Long id) {
        robotRepository.deleteById(id);
    }

    @Override
    @Transactional(readOnly = true)
    public RobotDTO get(Long id) {
        return robotRepository.findById(id).map(Mapper::toDTO)
                .orElseThrow(() -> new IllegalArgumentException("Robot not found"));
    }

    @Override
    @Transactional(readOnly = true)
    public List<RobotDTO> list() {
        return robotRepository.findAll().stream().map(Mapper::toDTO).toList();
    }
}
