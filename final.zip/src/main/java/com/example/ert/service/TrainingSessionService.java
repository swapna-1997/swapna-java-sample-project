package com.example.ert.service;

import com.example.ert.dto.TrainingSessionDTO;
import java.util.List;

public interface TrainingSessionService {
    TrainingSessionDTO schedule(TrainingSessionDTO dto);
    TrainingSessionDTO reschedule(Long id, TrainingSessionDTO dto);
    void cancel(Long id);
    TrainingSessionDTO get(Long id);
    List<TrainingSessionDTO> list();
    List<TrainingSessionDTO> listByCourse(Long courseId);
    List<TrainingSessionDTO> listByRobot(Long robotId);
}
