package com.example.ert.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Robot extends BaseEntity {

    @Column(nullable = false, unique = true)
    private String code; // unique robot code

    @Column(nullable = false)
    private String model;

    private String firmwareVersion;

    private boolean active = true;
}
