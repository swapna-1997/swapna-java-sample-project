package com.example.ert.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class TrainingSession extends BaseEntity {

    @ManyToOne(optional = false)
    private Course course;

    @ManyToOne(optional = false)
    private Robot robot;

    @Column(nullable = false)
    private LocalDateTime startTime;

    @Column(nullable = false)
    private LocalDateTime endTime;

    private String location;
}
